package day3;

public class AssignmentOperators {

	public static void main(String[] args) {
		
		//Assignment operators
		
		//ex1
		/*int a=10;
		//a=a+5;
		a+=5;
		System.out.println(a);
		*/
		
		
		//ex2
		/*int a=10;
		a-=5;    // a=a-5
		System.out.println(a);
			*/
		
		//ex3
			/*	int a=10;
				//a=a*2;
				a*=2;
				System.out.println(a);
				*/
		//ex4
		/*	int a=10;
			a/=2;	//a=a/2;
			System.out.println(a);
		*/
		
		//ex4
		int a=10;
		a%=2;	//a=a%2;
		System.out.println(a);
	
	}

}
