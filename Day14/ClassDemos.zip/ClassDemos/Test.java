package day14;


class ABC
{
	
}

class XYZ
{
	
}

public class Test {

	public static void main(String[] args) {
	
		ABC obj=new ABC();
		
		XYZ obj1=new XYZ();
		
		
	}

}
