package day12;

public class AdderMain {

	public static void main(String[] args) {
		
		Adder ad=new Adder();
		
		//ad.sum();  //1
		
		ad.sum(10.5,10); //5

	}

}
