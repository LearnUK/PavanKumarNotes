package day15;

public class TestSuper {

	public static void main(String[] args) {
	
		//Dog d=new Dog();
		
		//d.displayColor();
		//d.eat();
		
		Dog d=new Dog("Elephant");
	}

}
