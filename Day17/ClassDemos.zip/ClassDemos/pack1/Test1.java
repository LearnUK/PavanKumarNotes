package day17.pack1;

public class Test1 {

	/*private int x=100;
	
	private void m1()
	{
		System.out.println("this is m1 from Test1..");
	}
	*/
		
	/*int x=100;
	
	void m1()
	{
		System.out.println("this is m1 from Test1..");
	}
	*/
	
	/*protected int x=100;
	
	protected void m1()
	{
		System.out.println("this is m1 from Test1..");
	}
	*/
	public int x=100;
	
	public void m1()
	{
		System.out.println("this is m1 from Test1..");
	}
	
}
