package day17.pack1;

public class Test2 {

	public static void main(String arrs[])
	{
		Test1 t=new Test1();
		System.out.println(t.x);
		t.m1();
		
		
	}
}
