package day17.pack2;
import day17.pack1.Test1;


public class Test2 {

	public static void main(String arrs[])
	{
		Test1 t=new Test1();
		System.out.println(t.x);
		t.m1();
		
		
	}
}


/*public class Test2 extends Test1{

	public static void main(String arrs[])
	{
		Test2 t=new Test2();
		System.out.println(t.x);
		t.m1();
		
		
	}
}
*/