package day10;

public class Student {
	
	int sid;
	String sname;
	char grad;

	void printStudentData()
	{
		System.out.println(sid+"  "+sname+"    "+grad);
	}
	
	
}
