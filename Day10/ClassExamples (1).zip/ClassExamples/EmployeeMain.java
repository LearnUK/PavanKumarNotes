package day10;

public class EmployeeMain {

	public static void main(String[] args) 
	{
		Employee emp1=new Employee();
		emp1.eid=101;
		emp1.ename="Kim";
		emp1.job="Programmer";
		emp1.sal=30000;
		
		emp1.display();

	}

}
