package day4;

public class Ifcondition {

	public static void main(String[] args) {
		
		int person_age=20;
		
		if(person_age>=18)
		{
			System.out.println("Eligible for vote");
		}

	}

}
