package day4;

public class NumberPositiveNagitiveZero {

	public static void main(String[] args) {
		
		int num=0;
		
		if(num>0)
		{
			System.out.println("Number is Positive");
		}
		else if(num<0)
		{
			System.out.println("Number is Nagitive");
		}
		else 
		{
			System.out.println("Number is Zero");
		}

	}

}
