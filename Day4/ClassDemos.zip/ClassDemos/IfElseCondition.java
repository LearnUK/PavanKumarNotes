package day4;

public class IfElseCondition {

	public static void main(String[] args) {
		
		int person_age=10;
		
		if(person_age>=18)
		{
			System.out.println("Eligible for vote");
		}
		else
		{
			System.out.println("Not eligible for vote");
		}

	}

}
