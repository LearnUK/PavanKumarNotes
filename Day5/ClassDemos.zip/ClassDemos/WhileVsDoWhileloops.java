package day5;

public class WhileVsDoWhileloops {

	public static void main(String[] args) {
		
		// while loop
		/*int i=10;
		
		while(i<=5)
		{
			System.out.println(i);
			i++;
		}
		*/
		
		//do while loop
		int i=10;
		
		do
		{
			System.out.println(i); //10
			i++;  //11
		}while(i<=5);
		

	}

}
