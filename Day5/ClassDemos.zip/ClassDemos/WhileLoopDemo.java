package day5;

public class WhileLoopDemo 
{

	public static void main(String[] args) 
	{
		//Example1: 1.....10
		
		/*int i=1;  // initilization
		
		while(i<=10)    // condition
		{
			System.out.println(i);   
			i++;    // incrementation
		}
		*/
		
		//Example2 : print "hello"  10 times
		
		/*int i=1;
		
		while(i<=10)
		{
			System.out.println("hello");
			i++;
		}
		*/
		
		//Example3: print even numbers 1...10
		
		//method 1
		/*int i=2;
		while(i<=10)
		{
			System.out.println(i);
			i+=2;      //i=i+2;   
		}
		*/
		
		//method2
		
		/*int i=1;
		
		while(i<=10)
		{
			if(i%2==0)
			{
			System.out.println(i);
			}
			i++;
		}
		*/

		//odd numbers
		/*int i=1;
		
		while(i<=10)
		{
			if(i%2!=0)
			{
			System.out.println(i);
			}
			i++;
		}
		*/
		
		//Example 4
		
		//print 10 9 8 7 ......1
		
		/*int i=10;
		
		while(i>=1)
		{
			System.out.println(i);  //10  9  8  7 6 5 4 3 2 1 
			i--;
		}
		*/
		
		
		//Example5
		
		while(1==1)
		{
			System.out.println("hello");
		}
		
		
	}
}











