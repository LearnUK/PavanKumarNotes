package day5;

public class DoWhileLoop {

	public static void main(String[] args) {
		
		//print 1...10
		
		/*int i=1;
		do
		{
			System.out.println(i);
			i++;
		}while(i<=10);
		
		*/
		
		//10.....1
		
		int i=10;
		
		do
		{
			System.out.println(i);
			i--;
		}while(i>=1);

	}

}
